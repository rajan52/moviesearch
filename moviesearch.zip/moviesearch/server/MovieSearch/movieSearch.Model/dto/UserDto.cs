﻿using System;
using System.Collections.Generic;
using System.Text;

namespace movieSearch.Model.dto
{
   public class UserDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Role { get; set; }
    }
}
