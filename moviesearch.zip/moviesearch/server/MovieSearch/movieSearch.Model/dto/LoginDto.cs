﻿using System;
using System.Collections.Generic;
using System.Text;

namespace movieSearch.Model.dto
{
    public class LoginDto
    {
        public string token { get; set; }
    }
}
