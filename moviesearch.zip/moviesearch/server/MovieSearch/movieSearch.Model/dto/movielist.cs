﻿using System;
using System.Collections.Generic;
using System.Text;

namespace movieSearch.Model.dto
{
   public class movieList
    {
        public List<movie> movies { get; set; }
    }
}
