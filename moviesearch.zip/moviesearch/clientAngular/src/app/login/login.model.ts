export class LoginDto
{
    UserName:string;
    Password:string;
}

