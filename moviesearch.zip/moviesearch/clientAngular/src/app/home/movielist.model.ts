import { Movie } from 'src/app/home/movie.model';

export class MovieList
{
    movies: (Movie)[] ;
}