export class TokenDto
{
    token:string;
}